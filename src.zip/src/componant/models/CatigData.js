export const prod = [
    
    {
      id: 1,
      
  
      title: "Weman",
      
      imgSrc: "https://cdn.saksfifthavenue.com/is/image/saks/061124_SEO_EXISTING_AW_STYLISH_ACCESSORIES_YOU_NEED_FOR_SUMMER_EDIT_SLICE7?scl=1&qlt=85"
    },
    {
      id: 2,
      
  
      title: "Men",
      
      imgSrc: "https://static.zara.net/assets/public/d9dd/e853/274e4ed4825a/65bb838d9b4c/T1249352000-p/T1249352000-p.jpg?ts=1743682410901&w=352&f=auto",
    },
    {
      id: 3,
      
  
      title: "jewelry",
      
      
      imgSrc: "https://saachistyle.com/cdn/shop/collections/Untitled_design_31-536119.jpg?v=1683950741",
    },
   
   
  
   
  
  ];
  